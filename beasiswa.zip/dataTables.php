 <script>
      $(document).ready(function() {
            $('#myTable').DataTable();
      } );
  </script>