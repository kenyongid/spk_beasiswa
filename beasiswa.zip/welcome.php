<h1 align="center">SELAMAT DATANG</h1>
<h3 align="center">SISSTEM PENDUKUNG KEPUTUSAN PENERIMAAN BEASISWA</h3>
<h3 align="center"> Universitas PGRI Semarang</h3>